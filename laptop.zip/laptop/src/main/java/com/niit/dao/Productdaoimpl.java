	package com.niit.dao;

	import java.util.List;

import org.hibernate.Session;
	import org.hibernate.SessionFactory;
	import org.hibernate.Transaction;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Repository;
	import org.springframework.transaction.annotation.Propagation;
	import org.springframework.transaction.annotation.Transactional;

import com.niit.dao.Productdao;
import com.niit.model.Product;

	
	@Repository
	public class Productdaoimpl implements Productdao {
		
		
		@Autowired
		private SessionFactory sessionFactory;
		
		public SessionFactory getSession(SessionFactory sessionFactory){
			return this.sessionFactory=sessionFactory;
		}
		
		@Transactional(propagation=Propagation.SUPPORTS,readOnly=false)
		public void add(Product product) {
			// TODO Auto-generated method stub
			Session session = sessionFactory.openSession();
			Transaction transaction = (Transaction) session.beginTransaction();
			session.saveOrUpdate(product);
			transaction.commit();
			session.close();	
		}
		
		@Transactional(propagation=Propagation.SUPPORTS,readOnly=false)
		public void update(Product product) {
			// TODO Auto-generated method stub
			Session session = sessionFactory.openSession();
			Transaction transaction = (Transaction) session.beginTransaction();
			session.update(product);
			transaction.commit();
			session.close();	
		}

		@Transactional(propagation=Propagation.SUPPORTS,readOnly=false)
		public void delete(Product product) {
			// TODO Auto-generated method stub
			Session session = sessionFactory.openSession();
			Transaction transaction = (Transaction) session.beginTransaction();
			session.update(product);
			transaction.commit();
			session.close();	
		}

		@Transactional(propagation=Propagation.SUPPORTS,readOnly=false)
		public List<Product> getList() {
			// TODO Auto-generated method stub
			Session session = sessionFactory.openSession();
			Transaction transaction = (Transaction) session.beginTransaction();
			session.createQuery("fromproduct ").list();
			transaction.commit();
			session.close();
			return null;
		
			}

		@Transactional(propagation=Propagation.SUPPORTS,readOnly=false)
		public Product getProductById(int id) {
			// TODO Auto-generated method stub
			Session session = sessionFactory.openSession();
			Transaction transaction = (Transaction) session.beginTransaction();
			session.createQuery("from product where id proceed'"+id+"'").uniqueResult();
			transaction.commit();
			session.close();
			return null;
		}

		}
		
	

