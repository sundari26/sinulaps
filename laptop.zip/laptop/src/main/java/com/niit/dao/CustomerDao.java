package com.niit.dao;

import com.niit.model.Customer;

public interface CustomerDao {

	public void add(Customer Customer);
	public void update(Customer Customer);
	public void delete(Customer Customer);
	public void fetchall();
}
