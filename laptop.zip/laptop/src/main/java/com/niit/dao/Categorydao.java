package com.niit.dao;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.*;

@Repository("Categorydao")
public class Categorydao {
	@Autowired
	private SessionFactory sessionFactory;
	
	public Categorydao(SessionFactory sessionFactory) 
	{
		this.sessionFactory = sessionFactory;
	}
	
	@Transactional
	public void insert(com.niit.model.Category ob)
	{
		sessionFactory.getCurrentSession().saveOrUpdate(ob);
		System.out.println("Category Inserted");
	}
	
	@Transactional
	public void delete(int catid)
	{
			Category ob=(Category)sessionFactory.getCurrentSession().load(Category.class,catid);
			sessionFactory.getCurrentSession().delete(ob);
			System.out.println("Category gets Deleted");
	}
	
	@Transactional
	public List<Category> retrieve()
	{
		Query q=sessionFactory.getCurrentSession().createQuery("from Category");
		List<Category>ob=(List<Category>)q.list();
		return ob;
	}
	
	@Transactional
	public Category getCategoryData(int catid)
	{
		return (Category)sessionFactory.getCurrentSession().get(Category.class,catid);
	}

	@Transactional
	public void updateCategory(com.niit.model.Category ob)
	{
		sessionFactory.getCurrentSession().saveOrUpdate(ob);
		System.out.println("Category Updated");
	}

}

