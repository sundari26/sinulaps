package com.niit.dao;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.*;

@Repository("Customerdao")
public class Customerdao 
{
	@Autowired
	private SessionFactory sessionFactory;
	
	public Customerdao(SessionFactory sessionFactory) 
	{
		this.sessionFactory = sessionFactory;
	}
	
	@Transactional
	public void insert(com.niit.model.Customer ob)
	{
		sessionFactory.getCurrentSession().saveOrUpdate(ob);
		System.out.println("customer Inserted");
	}
	
	@Transactional
	public void delete(int cid)
	{
		Customer ob=(Customer)sessionFactory.getCurrentSession().load(Customer.class,cid);
			sessionFactory.getCurrentSession().delete(ob);
			System.out.println("customer gets Deleted");
	}
	
	@Transactional
	public List<Customer> retrieve()
	{
		Query q=sessionFactory.getCurrentSession().createQuery("from customer");
		List<Customer>ob=(List<Customer>)q.list();
		return ob;
	}
	
	@Transactional
	public Customer getcustomerData(int cid)
	{
		return (Customer)sessionFactory.getCurrentSession().get(Customer.class,cid);
	}

	@Transactional
	public void updatecustomer(com.niit.model.Customer ob)
	{
		sessionFactory.getCurrentSession().saveOrUpdate(ob);
		System.out.println("customer Updated");
	}

}

