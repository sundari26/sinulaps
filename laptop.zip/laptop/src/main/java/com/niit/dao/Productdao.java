package com.niit.dao;

import java.util.List;

import com.niit.model.Product;

public interface Productdao {
	
     public void add(Product product);
	
	public void update (Product product);
	
	public void delete(Product product);
	
	public List<Product> getList();
	
	public Product getProductById(int id);

}
