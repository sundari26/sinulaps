package com.niit.dao;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.*;

@Repository("Productdao")
public class Productdao 
{
	@Autowired
	private SessionFactory sessionFactory;
	
	public Productdao(SessionFactory sessionFactory) 
	{
		this.sessionFactory = sessionFactory;
	}
	
	@Transactional
	public void insert(com.niit.model.Product ob)
	{
		sessionFactory.getCurrentSession().saveOrUpdate(ob);
		System.out.println("Product Inserted");
	}
	
	@Transactional
	public void delete(int prodid)
	{
			Product ob=(Product)sessionFactory.getCurrentSession().load(Product.class,prodid);
			sessionFactory.getCurrentSession().delete(ob);
			System.out.println("Product gets Deleted");
	}
	
	@Transactional
	public List<Product> retrieve()
	{
		Query q=sessionFactory.getCurrentSession().createQuery("from Product");
		List<Product>ob=(List<Product>)q.list();
		return ob;
	}
	
	@Transactional
	public Product getProductData(int prodid)
	{
		return (Product)sessionFactory.getCurrentSession().get(Product.class,prodid);
	}

	@Transactional
	public void updateProduct(com.niit.model.Product ob)
	{
		sessionFactory.getCurrentSession().saveOrUpdate(ob);
		System.out.println("Product Updated");
	}

}
