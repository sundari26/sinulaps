package com.niit.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.Category;
import com.niit.dao.Categorydao;


@Repository
public class Categorydaoimpl implements Categorydao
{
@Autowired
private SessionFactory sessionFactory;

public SessionFactory getSession(SessionFactory sessionFactory) {

	return this.sessionFactory=sessionFactory ;

}
    @Transactional(propagation=Propagation.SUPPORTS,readOnly=false)
	public void save(Category category) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Transaction transaction = (Transaction) session.beginTransaction();
		session.saveOrUpdate(category);
		transaction.commit();
		session.close();
		
	}

    @Transactional(propagation=Propagation.SUPPORTS,readOnly=false)
	public void update(Category category) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Transaction transaction = (Transaction) session.beginTransaction();
		session.saveOrUpdate(category);
		transaction.commit();
		session.close();
		
	}

	@Override
	public List<Category> list() {
		// TODO Auto-generated method stub
		return null;
	}

		
	}


