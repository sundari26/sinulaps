package com.niit.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.Customer;


@Repository
public class Customerdaoimpl implements CustomerDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	public SessionFactory getSession(SessionFactory sessionFactory){
		return this.sessionFactory=sessionFactory;
	}
	
	@Transactional(propagation=Propagation.SUPPORTS,readOnly=false)
	public void add(Customer Customer) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Transaction transaction = (Transaction) session.beginTransaction();
		session.save(Customer);
		transaction.commit();
		session.close();
	}

	@Transactional(propagation=Propagation.SUPPORTS,readOnly=false)
	public void update(Customer Customer) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Transaction transaction = (Transaction) session.beginTransaction();
		session.update(Customer);
		transaction.commit();
		session.close();
	}

	@Transactional(propagation=Propagation.SUPPORTS,readOnly=false)
	public void delete(Customer Customer) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Transaction transaction = (Transaction) session.beginTransaction();
		session.delete(Customer);
		transaction.commit();
		session.close();
	}

	@Transactional(propagation=Propagation.SUPPORTS,readOnly=false)
	public void fetchall() {
		// TODO Auto-generated method stub
		
	}

}
