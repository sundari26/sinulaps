package com.niit.dao;

import com.niit.model.Supplier;

public interface Supplierdao {


	public void add(Supplier supplier);
	
	public void update(Supplier supplier);
	
	public void delete(Supplier supplier);

	public void fetchAll();
	
	
	


}
