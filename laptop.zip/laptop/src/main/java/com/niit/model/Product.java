package com.niit.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Product {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	 private int id;
	 private int price;
	 private int stock;
	 private String detail;
	 private String name;
	public int getid() {
		return id;
	}
	public void setProdid(int prodid) {
		this.id = prodid;
	}

	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	public String getProdname() {
		return name;
	}
	public void setProdname(String prodname) {
		this.name = prodname;
	}
}