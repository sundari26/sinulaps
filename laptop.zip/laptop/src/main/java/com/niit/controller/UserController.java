package com.niit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.dao.CustomerDao;
import com.niit.model.Customer;

@Controller
public class UserController {
	
	@Autowired
	CustomerDao customerDao;

	@RequestMapping("/registerPage")
	public String register(){
		return "Registration";
	}
	@ModelAttribute("reg")
	public Customer getCust(){
		return new Customer();
	}
	
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public String registerUser(@ModelAttribute("reg")Customer customer, BindingResult result, Model model){
		
		customerDao.add(customer);
		model.addAttribute("message", "Congo..!!! successfully registered");
		return "index1";
	}
}
