package com.niit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.niit.model.Supplier;


@Controller
public class SupplierController {
	@Autowired
	@ModelAttribute("addSup")
	public Supplier getSupplierCmd(){
		return new Supplier();
	}
	
	@RequestMapping(value="/addSupplier",method=RequestMethod.POST)
	public String addsupplier(@ModelAttribute("addSup")Supplier supplier,BindingResult result){
	
		
		return "Supplier";
	}

	@ModelAttribute("updateSup")
	public Supplier getSupplier(){
		return new Supplier();
	}
	
	@RequestMapping(value="/updateSupplier",method=RequestMethod.POST)
	public String editsupplier(@ModelAttribute("updateSup")Supplier supplier,BindingResult result){
		
	
		return "Supplier";
	}
	
	@ModelAttribute("deleteSup")
	public Supplier getSupplierCommand(){
		return new Supplier();
	}
	
	@RequestMapping(value="/deleteSupplier",method=RequestMethod.POST)
	public String deleteSupplier(@ModelAttribute("deleteSup")Supplier supplier,BindingResult result){
		return "Supplier";
	}
}
