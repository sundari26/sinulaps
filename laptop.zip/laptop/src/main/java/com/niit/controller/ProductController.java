package com.niit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.dao.Productdao;

import com.niit.model.Product;

@Controller
@RequestMapping("/admin")
public class ProductController 
{
	@Autowired

	Productdao productdao;

	@RequestMapping("/productPage")
	public String product(){
		return "Products";
	}

	@ModelAttribute("addProd")
	public Product getProductCmd(){
		return new Product();
	}

	@RequestMapping(value="/addProduct",method=RequestMethod.POST)
	public String addproduct(@ModelAttribute("addProd")Product product,BindingResult result){
		
		return "Products";
	}
	@Autowired
	@ModelAttribute("updateProd")
	public Product getProduct(){
		return new Product();
	}
 
	@RequestMapping(value="/updateProduct",method=RequestMethod.POST)
	public String updateproduct(@ModelAttribute("updateProd")Product product,BindingResult result){
		

		
		return "Products";
	}
	@Autowired
	@ModelAttribute("deleteProd")
	public Product getProduct1(){
		return new Product();
	}

	@RequestMapping(value="/deleteProduct",method=RequestMethod.POST)
	public String deleteproduct(@ModelAttribute("deleteProd")Product product,BindingResult result){
		

		
		return "Products";
	}
	
	@RequestMapping(value="/addProducts")
	public String Products(Model model) {
		model.addAttribute("addProduct");
		return "index1";
	}

	
}
