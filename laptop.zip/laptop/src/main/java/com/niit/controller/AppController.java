package com.niit.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AppController {
	@RequestMapping("/")
	public String index1() {
		return "index1";
	}

	@RequestMapping("/login")
	public String login() {
		return "login";
	}

	@RequestMapping("/Registration")
	public String registration() {
		return "Registration";
	}

	@RequestMapping("/product")
	public String product() {
		return "product";
	}
	@RequestMapping("/about")
	public String about() {
		return "about";
	}
		@RequestMapping("/contact")
		public String contact() {
			return "contact";
	}

}