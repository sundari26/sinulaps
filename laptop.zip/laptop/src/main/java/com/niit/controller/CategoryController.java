package com.niit.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.dao.*;
import com.niit.model.*;
@Controller
public class CategoryController {
	@Autowired
	Categorydao cdao;
	
	@RequestMapping("Category")
	public String showCategory(Model m)
	{	
		com.niit.model.Category category=new com.niit.model.Category();
		m.addAttribute(category);
		List<Category> catlist=cdao.retrieve();
		m.addAttribute("CatList",catlist);
		
		return "Category";
	}
	
	@RequestMapping(value="InsertCategory",method=RequestMethod.POST)
	public String insertCategory(@ModelAttribute("Category")Category category,Model m)
	{
		cdao.insert(category);
		
		List<Category> catlist=cdao.retrieve();
		m.addAttribute("CatList",catlist);
		
		return "Category";
	}
	
	@RequestMapping("deleteCategory/{id}")
	public String deleteCategory(@PathVariable("id") int catid,Model m)
	{
		Category category=new Category();
		m.addAttribute(category);
		cdao.delete(catid);
		System.out.println("Successfully deleted");
		List<Category> catlist=cdao.retrieve();
		m.addAttribute("CatList",catlist);
		return "Category";
	}

	@RequestMapping("Updatecategory/{id}")
	public String updatecategory(@PathVariable("id") int catid,Model m)
	{
		Category category=cdao.getCategoryData(catid);
		m.addAttribute(category);
		return "UpdateCategory";
	}
	
	@RequestMapping(value="UpdateCategory1",method=RequestMethod.POST)
	public String updateCategory(@ModelAttribute("Category")Category category,Model m)
	{
		cdao.updateCategory(category);
		
		List<Category> catlist=cdao.retrieve();
		m.addAttribute("CatList",catlist);
		Category category1=new Category();
		m.addAttribute(category1);
		
		return "Category";
	}

}

