package com.niit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.model.Category;
import com.niit.dao.Categorydao;
@Controller
public class CategoryController {

	@Autowired
	Categorydao Categorydao;
	
	@RequestMapping("/Categorypage")
	public String Category(){
		return "Category";
	}
	@ModelAttribute("savecat")
	public Category getCat(){
		return new Category();
	}
	@ModelAttribute("saveCat")
	public Category getCategory1(){
		return new Category();
	}

	@RequestMapping(value="/saveCategory",method=RequestMethod.POST)
	public String saveCategory(@ModelAttribute("saveCat")Category category,BindingResult result){
		
		return "Category";
		
	}
		@Autowired
		@ModelAttribute("updateCat")
		public Category getCategory(){
			return new Category();
		}

		@RequestMapping(value="/updateCategory",method=RequestMethod.POST)
		public String updateCategory(@ModelAttribute("updateCat")Category category,BindingResult result){
			
			return "Category";
		}}
	

